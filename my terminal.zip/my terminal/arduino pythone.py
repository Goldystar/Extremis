#simple led program
import pyfirmata
import time
import my_terminal

board = pyfirmata.Arduino('COM3')

while True:
    board.digital[13].write(1)
    time.sleep(0.5)
    board.digital[13].write(0)
    time.sleep(0.5)